# Web Development Activity-Based Learning (ABL) Project

**Institution:** Dr. RVR NRI Institute of Technology  
**Course:** Web Development  
**Project scope:** Three case studies selected from the supplied university task list.

## Selected case studies
1. **Personal Portfolio Website** — profile, education, skills, hobbies, projects, achievements, resume section, contact form, responsive navigation, and CSS animation.
2. **College Information and Admissions Website** — institutional overview, departments, courses, facilities, admissions steps, campus events, contact information, and responsive cards.
3. **Online Learning Platform Interface** — course categories, course cards, instructor profiles, learning objectives, progress indicators, and enrollment interactions.

## Technologies
- HTML5 (semantic page structure and accessible forms)
- CSS3 (responsive layouts, Grid, Flexbox, transitions, animations)
- Vanilla JavaScript (navigation, filters, form validation, enrollment feedback, progress interaction)

## How to run
1. Extract the ZIP archive.
2. Open `index.html` in a modern browser, or use VS Code's Live Server extension.
3. Use the top navigation to open each case study.
4. Try the search/filter controls, mobile navigation, contact form validation, and course enrollment buttons.

No build tools or external libraries are required. The site is a front-end demonstration; form submissions and course enrollment are demo interactions and do not send data to a server.

## Folder structure
```text
Web-Development-ABL-Project/
├── index.html
├── portfolio.html
├── college.html
├── learning.html
├── css/
│   └── styles.css
├── js/
│   └── main.js
├── report/
│   └── project-documentation.md
├── README.md
└── .gitignore
```

## Before submission
Personalize the portfolio name, contact details, academic information, and project details. Verify all content with your faculty instructions and be prepared to explain the code.
