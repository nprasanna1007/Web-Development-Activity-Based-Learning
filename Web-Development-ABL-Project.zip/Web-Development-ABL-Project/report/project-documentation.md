# Web Development Activity-Based Learning — Project Documentation

## 1. Introduction
This project implements three case studies selected from the university-provided “Web Development Activity-Based Learning” task list: Personal Portfolio Website, College Information and Admissions Website, and Online Learning Platform Interface. The pages share a common navigation system and visual design language.

## 2. Objectives
- Practise semantic HTML and organized page structure.
- Create responsive layouts using CSS Grid, Flexbox, and media queries.
- Apply CSS transitions and animations where appropriate.
- Use JavaScript to implement client-side interactions.
- Design readable, keyboard-accessible navigation and form controls.
- Document project structure, use cases, and testing.

## 3. Requirements
- A modern browser (Chrome, Edge, Firefox, or equivalent).
- Optional: Visual Studio Code with Live Server.
- No package installation, build system, database, or backend is required.

## 4. Case Study 01 — Personal Portfolio Website
### Features
- Profile introduction and editable placeholder content.
- Education timeline, projects, achievements, interests, and skill indicators.
- Resume section and contact details.
- Responsive layout and animated visual elements.
- Contact form with HTML constraints and JavaScript validation feedback.

### Validation note
The contact form is a front-end demonstration. It does not transmit or store data. Replace sample name, qualifications, contact details, skill levels, and achievements with accurate personal information.

## 5. Case Study 02 — College Information and Admissions Website
### Features
- Hero banner and responsive navigation.
- Institutional overview, programme cards, facilities, admission steps, and sample campus events.
- Responsive information cards and CSS campus illustration.
- Link to the institution's website for checking official information.

### Validation note
Programme names and events are illustrative interface content. Confirm actual departments, eligibility, dates, fees, campus facilities, and contact information using official institutional sources before publication.

## 6. Case Study 03 — Online Learning Platform Interface
### Features
- Search field and category filters.
- Course cards with course descriptions, instructor profiles, lesson counts, and progress bars.
- Enroll buttons with accessible demo feedback.
- Empty state when a search finds no matching courses.
- Responsive course grid.

### Validation note
Courses, instructor names, and progress values are sample content. The enrollment action is a demonstration only; there is no authentication, backend, or persistent enrollment.

## 7. Technologies
- HTML5: semantic elements, links, forms, labels, validation attributes.
- CSS3: custom properties, responsive breakpoints, Grid, Flexbox, transitions, keyframe animation, reduced-motion support.
- JavaScript: mobile navigation, contact form feedback, course filtering, search, and enrollment toast.

## 8. Test Plan
| ID | Test | Expected result |
|---|---|---|
| T01 | Open `index.html` | Project hub and three case-study links display. |
| T02 | Follow each project link | Correct page opens through the shared navigation. |
| T03 | Resize browser to mobile width | Navigation collapses to a toggle; content reflows. |
| T04 | Submit the contact form with empty fields | Browser validation prevents successful submission. |
| T05 | Submit valid contact form values | Local success message appears; no data is sent. |
| T06 | Filter courses by Programming | Only programming category cards remain visible. |
| T07 | Search for “Python” | Matching Python course appears. |
| T08 | Search for an unmatched term | Empty-state message appears. |
| T09 | Select Enroll in course | Demo toast explains no actual enrollment occurred. |
| T10 | Use keyboard Tab navigation | Interactive links, buttons, and form controls can receive focus. |

## 9. Algorithms
### Responsive navigation
1. Wait for page DOM to load.
2. When the navigation toggle is activated, toggle the menu's open state.
3. Update `aria-expanded` and the button label.
4. Close the menu when a navigation link is selected.

### Course filtering
1. Read the selected category and search text.
2. For each course, check both category and text match.
3. Show cards satisfying both conditions; hide the others.
4. Update the result count.
5. Display the empty state if no cards match.

### Contact form demonstration
1. Prevent actual browser submission.
2. Check the form's built-in validation constraints.
3. If invalid, ask the browser to report validation errors.
4. If valid, display local success feedback and reset the form.
5. Do not send or persist the entered information.

## 10. Limitations and Future Enhancements
- Contact and enrollment actions are front-end only.
- No database, user accounts, server-side processing, or real course videos are provided.
- Official college details must be verified before publication.
- Future work could add a backend, real course content, downloadable resume, and secure form submission.

## 11. Conclusion
The project demonstrates the construction of three responsive web interfaces with HTML, CSS, and JavaScript. It combines content presentation, reusable styling, responsive navigation, form validation feedback, course search, and category filtering in a single organized project folder.
