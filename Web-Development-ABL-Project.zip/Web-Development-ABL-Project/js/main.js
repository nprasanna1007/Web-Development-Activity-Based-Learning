document.addEventListener("DOMContentLoaded", () => {
  // Responsive navigation shared by all pages.
  const toggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".main-nav");
  if (toggle && nav) {
    toggle.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(isOpen));
      toggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Toggle navigation");
      toggle.textContent = isOpen ? "×" : "☰";
    });
    nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
      nav.classList.remove("open");
      toggle.setAttribute("aria-expanded", "false");
      toggle.setAttribute("aria-label", "Toggle navigation");
      toggle.textContent = "☰";
    }));
  }

  // Contact form demonstration: validate input locally, never transmit or store it.
  const contactForm = document.querySelector("#contact-form");
  if (contactForm) {
    const status = contactForm.querySelector(".form-status");
    contactForm.addEventListener("submit", event => {
      event.preventDefault();
      status.className = "form-status";
      if (!contactForm.checkValidity()) {
        contactForm.reportValidity();
        status.textContent = "Please check the highlighted fields and try again.";
        status.classList.add("error");
        return;
      }
      status.textContent = "Form validation successful! This demo does not send your message.";
      status.classList.add("success");
      contactForm.reset();
    });
  }

  // E-learning course category filters and text search.
  const courseGrid = document.querySelector("#course-grid");
  if (courseGrid) {
    const cards = Array.from(courseGrid.querySelectorAll(".course-card"));
    const filterButtons = Array.from(document.querySelectorAll(".filter-btn"));
    const searchInput = document.querySelector("#course-search");
    const searchButton = document.querySelector("#search-button");
    const resultCount = document.querySelector("#result-count");
    const emptyState = document.querySelector("#empty-state");
    let activeFilter = "all";

    const updateCourses = () => {
      const query = (searchInput?.value || "").trim().toLowerCase();
      let shown = 0;
      cards.forEach(card => {
        const categoryMatch = activeFilter === "all" || card.dataset.category === activeFilter;
        const text = `${card.dataset.title || ""} ${card.textContent || ""}`.toLowerCase();
        const searchMatch = !query || text.includes(query);
        const visible = categoryMatch && searchMatch;
        card.hidden = !visible;
        if (visible) shown += 1;
      });
      resultCount.textContent = `Showing ${shown} of ${cards.length} courses`;
      emptyState.hidden = shown !== 0;
    };

    filterButtons.forEach(button => button.addEventListener("click", () => {
      activeFilter = button.dataset.filter || "all";
      filterButtons.forEach(item => {
        const selected = item === button;
        item.classList.toggle("active", selected);
        item.setAttribute("aria-pressed", String(selected));
      });
      updateCourses();
    }));
    searchInput?.addEventListener("input", updateCourses);
    searchButton?.addEventListener("click", updateCourses);
    searchInput?.addEventListener("keydown", event => {
      if (event.key === "Enter") {
        event.preventDefault();
        updateCourses();
      }
    });

    const toast = document.querySelector("#toast");
    let toastTimer;
    const showToast = message => {
      if (!toast) return;
      toast.textContent = message;
      toast.classList.add("show");
      window.clearTimeout(toastTimer);
      toastTimer = window.setTimeout(() => toast.classList.remove("show"), 3600);
    };
    document.querySelectorAll(".enroll-btn").forEach(button => {
      button.addEventListener("click", () => {
        showToast(`Demo interaction: “${button.dataset.course}” selected. No account or enrollment record was created.`);
      });
    });
    updateCourses();
  }
});
